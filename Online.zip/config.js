exports.db = {
    host: "airport-system.cas2p4oocqgu.us-east-1.rds.amazonaws.com",
    user: "AirportSystem",
    password: "jigglypuff",
    database: "Airport_System"
};
