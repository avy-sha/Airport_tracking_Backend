exports.db = {
    host: "airport-system.cas2p4oocqgu.us-east-1.rds.amazonaws.com",
    user: "AirportSystem",
    password: "jigglypuff",
    database: "Airport_System"
};

/*exports.db = {
    accessKeyId:"AKIAJGXRVCHFOGG7WZOA",
    secretAccessKey:"GLSCnzD7yCDE5Q7jvgpA/RfCnTF+/QplyCrT12ie",


}*/

exports.mail_acc={
  username:"sampleserver00@gmail.com",
  password:"!@Samp123"
};
